//This variable holds the childs height in inches
var childsHeight = 54
//This function is a conditional to display whether or not the child is tall enough to ride the rollercoaster.
function displayIfChildIsAbleToRideTheRollercoaster(){
    if (childsHeight >= 52 ) {
        console.log("Get on the ride, kiddo!");  //If the child is 52 or more inches tall they can ride.
    }
    else {
        console.log("Sorry kiddo. Maybe next year.") //If the child is less than 52 inches they cannot ride.
    }
}
displayIfChildIsAbleToRideTheRollercoaster() //Calls the function.
